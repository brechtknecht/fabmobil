<template>
  <span class="social">
    <a href="https://twitter.com/getkirby">
      <img src="~/assets/icons/twitter.svg" />
    </a>
    <a href="https://chat.getkirby.com">
      <img src="~/assets/icons/discord.svg" />
    </a>
    <a href="https://instagram.com/getkirby">
      <img src="~/assets/icons/instagram.svg" />
    </a>
  </span>
</template>
