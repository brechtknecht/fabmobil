<script setup lang="ts">
import type { KirbyBlock } from '#nuxt-kql'

defineProps<{
  block: KirbyBlock<'quote'>
}>()
</script>

<template>
  <blockquote class="max-w-prose mx-auto">
    <div class="font-body text-callout" v-html="block.content.text" />
    <footer v-html="block.content.citation" />
  </blockquote>
</template>
